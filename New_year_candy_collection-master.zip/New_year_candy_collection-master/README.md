# New_year_candy_collection
java program using maven executed using intellij

This project helps to estimate total minimum and maximum prices and weights of all candies chidren get on events like
New year,halloween,birthday parties and other events 
